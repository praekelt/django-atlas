/*
 $Id: calc_distance_spheroid.cc 284 2008-07-08 02:52:53Z okum $

 calc_distance_spheroid.cc - calculate linear distance in meters between two lat/lon points.

 Copyright 2008 Oki Electric Industry Co., Ltd.
 Copyright 2001-2003 Refractions Research Inc.

 This program is derived from lwgeom_spheroid.c in PostGIS, which 
 is released under the GNU General Public Licence version 2 by 
 Refractions Research Inc, <http://postgis.refractions.net>.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2 as 
 published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program. If not, see <http://www.gnu.org/licenses/>.

 Date: July 2008
 Author: Koji Okumura at OKI (Oki Electric Industry Co., Ltd.)
 URL: http://www.okilab.jp/

*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "calc_distance_spheroid.h"

/*
 * This function that is derived from ellipsoid_in() contributed to PostGIS
 * returns NULL if error
 *
 * Use the WKT definition of an ellipsoid
 * ie. SPHEROID["name",A,rf] or SPHEROID("name",A,rf)
 *        SPHEROID["GRS_1980",6378137,298.257222101]
 * wkt says you can use "(" or "["
 */
SPHEROID*
str2spheroid(const char *str, SPHEROID *sphere){

  int nitems;
  double rf;
  
  if(strstr(str,"SPHEROID") != str){
    return NULL;
  }
 
  memset(sphere, 0, sizeof(SPHEROID));
  nitems = sscanf(str,"SPHEROID[\"%19[^\"]\",%lf,%lf]",
		  sphere->name, &sphere->a, &rf);
  if(nitems != 3){
    nitems = sscanf(str,"SPHEROID(\"%19[^\"]\",%lf,%lf)",
		    sphere->name, &sphere->a, &rf);
  }
  if(nitems != 3){
    return NULL;
  }
  sphere->f = 1.0/rf;
  sphere->b = sphere->a - (1.0/rf)*sphere->a;
  sphere->e_sq = ((sphere->a*sphere->a) - (sphere->b*sphere->b)) /
    (sphere->a*sphere->a);
  sphere->e = sqrt(sphere->e_sq);

  return sphere;
}

/*
 * This function is derived from deltaLongitude() that is
 *
 * support function for distance calc
 * code is taken from David Skea
 * Geographic Data BC, Province of British Columbia, Canada.
 * Thanks to GDBC and David Skea for allowing this to be
 * put in PostGIS.
 */
static double
deltaLongitude(double azimuth, double sigma, double tsm,SPHEROID *sphere)
{
  
  /* compute the expansion C */
  double das,C;
  double ctsm,DL;
  das = cos(azimuth)*cos(azimuth);
  C = sphere->f/16.0 * das * (4.0 + sphere->f * (4.0 - 3.0 * das));

  /* compute the difference in longitude */
  ctsm = cos(tsm);
  DL = ctsm + C * cos(sigma) * (-1.0 + 2.0 * ctsm*ctsm);
  DL = sigma + C * sin(sigma) * DL;
  
  return (1.0 - C) * sphere->f * sin(azimuth) * DL;
}

/*
 * This function is derived from mu2() that is
 *
 * support function for distance calc
 * code is taken from David Skea
 * Geographic Data BC, Province of British Columbia, Canada.
 *  Thanks to GDBC and David Skea for allowing this to be
 *  put in PostGIS.
 */
static double
mu2(double azimuth,SPHEROID *sphere)
{
  double    e2;
  e2 = sqrt(sphere->a*sphere->a-sphere->b*sphere->b)/sphere->b;
  return cos(azimuth)*cos(azimuth) * e2*e2;
}

/*
 * This function is derived from bigA() that is
 *
 * Support function for distance calc
 * code is taken from David Skea
 * Geographic Data BC, Province of British Columbia, Canada.
 *  Thanks to GDBC and David Skea for allowing this to be
 *  put in PostGIS.
 */
static double
bigA(double u2)
{
  return 1.0 + u2/256.0 * (64.0 + u2 * (-12.0 + 5.0 * u2));
}

/*
 * This function is derived from bigA() that is
 *
 * Support function for distance calc
 * code is taken from David Skea
 * Geographic Data BC, Province of British Columbia, Canada.
 *  Thanks to GDBC and David Skea for allowing this to be
 *  put in PostGIS.
 */
static double
bigB(double u2)
{
  return u2/512.0 * (128.0 + u2 * (-64.0 + 37.0 * u2));
}

/*
 * This function that is derived from distance_ellipse_calculation()
 * contributed to PostGIS
 */
double calc_distance_spheroid(double x1, double y1, double x2, double y2,
			      SPHEROID *sphere){

  /*
   * Code is taken from David Skea
   * Geographic Data BC, Province of British Columbia, Canada.
   *  Thanks to GDBC and David Skea for allowing this to be
   *  put in PostGIS.
   */

  double lat1 = y1 * M_PI/180.0;
  double long1 = x1 * M_PI/180.0;
  double lat2 = y2 * M_PI/180.0;
  double long2 = x2 * M_PI/180.0;

  double L1,L2,sinU1,sinU2,cosU1,cosU2;
  double dl,dl1,dl2,dl3,cosdl1,sindl1;
  double cosSigma,sigma,azimuthEQ,tsm;
  double u2,A,B;
  double dsigma;

  double TEMP;
  int iterations;

  L1 = atan((1.0 - sphere->f ) * tan( lat1) );
  L2 = atan((1.0 - sphere->f ) * tan( lat2) );
  sinU1 = sin(L1);
  sinU2 = sin(L2);
  cosU1 = cos(L1);
  cosU2 = cos(L2);

  dl = long2- long1;
  dl1 = dl;
  cosdl1 = cos(dl);
  sindl1 = sin(dl);
  iterations = 0;
  do {
    cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosdl1;
    sigma = acos(cosSigma);
    azimuthEQ = asin((cosU1 * cosU2 * sindl1)/sin(sigma));

    /*
     * Patch from Patrica Tozer to handle minor
     * mathematical stability problem
     */
    TEMP = cosSigma - (2.0 * sinU1 * sinU2)/
      (cos(azimuthEQ)*cos(azimuthEQ));
    if(TEMP > 1)
      {
	TEMP = 1;
      }
    else if(TEMP < -1)
      {
	TEMP = -1;
      }
    tsm = acos(TEMP);

    /* (old code?)
       tsm = acos(cosSigma - (2.0 * sinU1 * sinU2)/(cos(azimuthEQ)*cos(azimuthEQ)));
    */

    dl2 = deltaLongitude(azimuthEQ, sigma, tsm,sphere);
    dl3 = dl1 - (dl + dl2);
    dl1 = dl + dl2;
    cosdl1 = cos(dl1);
    sindl1 = sin(dl1);
    iterations++;
  } while ( (iterations<999) && (fabs(dl3) > 1.0e-032));

  /* compute expansions A and B */
  u2 = mu2(azimuthEQ,sphere);
  A = bigA(u2);
  B = bigB(u2);

  /* compute length of geodesic */
  dsigma = B * sin(sigma) * (cos(tsm) +
			     (B*cosSigma*(-1.0 + 2.0 * (cos(tsm)*cos(tsm))))/4.0);
  return sphere->b * (A * (sigma - dsigma));
}

/*
 * This function that is derived from LWGEOM_distance_sphere()
 * contributed to PostGIS
 *
 * This algorithm was taken from the geo_distance function of the
 * earthdistance package contributed by Bruno Wolff III.
 * It was altered to accept GEOMETRY objects and return results in
 * meters
 */
double calc_distance_sphere(double x1, double y1, double x2, double y2)
{
  
  const double EARTH_RADIUS = 6370986.884258304;

  double long1 = -2 * (x1 / 360.0) * M_PI;
  double lat1 = 2 * (y1 / 360.0) * M_PI;
  double long2 = -2 * (x2 / 360.0) * M_PI;
  double lat2 = 2 * (y2 / 360.0) * M_PI;

  /* compute difference in longitudes - want < 180 degrees */
  double longdiff = fabs(long1 - long2);
  if (longdiff > M_PI) {
    longdiff = (2 * M_PI) - longdiff;
  }
  
  double sino = sqrt(sin(fabs(lat1 - lat2) / 2.)
		     * sin(fabs(lat1 - lat2) / 2.)
		     + cos(lat1) * cos(lat2)
		     * sin(longdiff / 2.) * sin(longdiff / 2.));
  if (sino > 1.){
    sino = 1.;
  }
  
  double result = 2. * EARTH_RADIUS * asin(sino);
  
  return result;
}
