/* 
 $Id: calc_distance_spheroid.h 284 2008-07-08 02:52:53Z okum $

 calc_distance_spheroid.h - calculate linear distance in meters between two lat/lon points.

 Copyright 2008 Oki Electric Industry Co., Ltd.
 Copyright 2001-2003 Refractions Research Inc.

 This program is derived from lwgeom_spheroid.c in PostGIS, which 
 is released under the GNU General Public Licence version 2 by 
 Refractions Research Inc, <http://postgis.refractions.net>.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2 as 
 published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program. If not, see <http://www.gnu.org/licenses/>.

 Date: July 2008
 Author: Koji Okumura at OKI (Oki Electric Industry Co., Ltd.)
 URL: http://www.okilab.jp/

*/

#ifndef _CALC_DISTANCE_SPHEROID_H_
#define _CALC_DISTANCE_SPHEROID_H_

/*
 * This struct is same contributed to PostGIS 
 *
 * standard definition of an ellipsoid (what wkt calls a spheroid)
 *    f = (a-b)/a
 *    e_sq = (a*a - b*b)/(a*a)
 *    b = a - fa
 */
typedef struct
{
  double  a;      /* semimajor axis */
  double  b;      /* semiminor axis */
  double  f;      /* flattening     */
  double  e;      /* eccentricity (first) */
  double  e_sq;   /* eccentricity (first), squared */
  char    name[20]; /* name of ellipse */
} SPHEROID;

/*
 * This function that is derived from ellipsoid_in() contributed to PostGIS
 * returns NULL if error
 *
 * Use the WKT definition of an ellipsoid
 * ie. SPHEROID["name",A,rf] or SPHEROID("name",A,rf)
 *        SPHEROID["GRS_1980",6378137,298.257222101]
 * wkt says you can use "(" or "["
 */
extern SPHEROID*
str2spheroid(const char *str, SPHEROID *sphere);

/*
 * This function that is derived from distance_ellipse_calculation()
 * contributed to PostGIS
 */
extern double
calc_distance_spheroid(double x1, double y1, double x2, double y2,
		       SPHEROID *sphere);

/*
 * This function that is derived from LWGEOM_distance_sphere()
 * contributed to PostGIS
 *
 * This algorithm was taken from distance_sphere() in PostGIS. 
 * It was taken from the geo_distance function of the
 * earthdistance package contributed by Bruno Wolff III.
 * It was altered to accept GEOMETRY objects and return results in
 * meters.
 */
extern double
calc_distance_sphere(double x1, double y1, double x2, double y2);

#endif
