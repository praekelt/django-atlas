/* 
 $Id: udf_distance_spheroid.cc 284 2008-07-08 02:52:53Z okum $

 udf_distance_spheroid.cc - UDF to calculate linear distance in meters between two lat/lon points.

 Copyright 2008 Oki Electric Industry Co., Ltd.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License version 2 as 
 published by the Free Software Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program. If not, see <http://www.gnu.org/licenses/>.

 Date: July 2008
 Author: Koji Okumura at OKI (Oki Electric Industry Co., Ltd.)
 URL: http://www.okilab.jp/

*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "mysql_priv.h"
#include "spatial.h"
#include "calc_distance_spheroid.h"

extern "C" {
  my_bool distance_spheroid_init(UDF_INIT *initid,
				 UDF_ARGS *args,
				 char *message);
  double distance_spheroid(UDF_INIT *initid,
			   UDF_ARGS *args,
			   char *is_null,
			   char *error);
  void distance_spheroid_deinit(UDF_INIT *initid);

  my_bool distance_sphere_init(UDF_INIT *initid,
				 UDF_ARGS *args,
				 char *message);
  double distance_sphere(UDF_INIT *initid,
			 UDF_ARGS *args,
			 char *is_null,
			 char *error);
  void distance_sphere_deinit(UDF_INIT *initid);
};

#define SPHEROID_MAXLEN 128

my_bool distance_spheroid_init(UDF_INIT *initid,
			       UDF_ARGS *args,
			       char *message)
{
  if(args->arg_count != 3){
    strcpy(message,
	   "wrong number of arguments: DISTANCE_SPHEROID() requires three arguments");
    return 1;
  }
  initid->decimals = 10;
  initid->maybe_null = 1; // The result may be null

  if(args->arg_type[0] != STRING_RESULT
     || args->arg_type[1] != STRING_RESULT
     || args->arg_type[2] != STRING_RESULT){
    strcpy(message,
	   "wrong argument type: DISTANCE_SPHEROID() requires two GEOMETRY and a STRING");
    return 1;
  }

  return 0; // OK
}

double distance_spheroid(UDF_INIT *initid,
			 UDF_ARGS *args,
			 char *is_null,
			 char *error)
{
  if(args->args[0] == 0 || args->args[1] == 0){ // Return NULL for NULL values
    *is_null = 1;
    return 0;
  }

  if(args->lengths[0] < sizeof (Geometry)
     || args->lengths[1] < sizeof (Geometry)
     || args->lengths[2] < 8){ // = strlen("SPHEROID")
    *error = 1;
    return 0;
  }

  Geometry *g1, *g2;
  Geometry_buffer buffer1, buffer2;
  g1 = Geometry::construct(&buffer1, args->args[0], args->lengths[0]);
  g2 = Geometry::construct(&buffer2, args->args[1], args->lengths[1]);
  int mtypeid1 = g1->get_class_info()->m_type_id;
  int mtypeid2 = g1->get_class_info()->m_type_id;
  if(mtypeid1 != Geometry::wkb_point || mtypeid2 != Geometry::wkb_point){
    *error = 1;
    return 0;
  }

  double x1, x2, y1, y2;
  ((Gis_point *)g1)->get_xy(&x1, &y1);
  ((Gis_point *)g2)->get_xy(&x2, &y2);
  if(x1 == x2 && y1 == y2){
    return 0.0;
  }

  SPHEROID spheroid;
  char spheroid_buf[SPHEROID_MAXLEN];
  memcpy(spheroid_buf, args->args[2], 
	 args->lengths[2] < SPHEROID_MAXLEN
	 ? args->lengths[2] : SPHEROID_MAXLEN);
  spheroid_buf[args->lengths[2]] = 0;

  if(str2spheroid(spheroid_buf, &spheroid) == NULL){
    *error = 1;
    return 0;
  }

  return calc_distance_spheroid(x1, y1, x2, y2, &spheroid);
}

void distance_spheroid_deinit(UDF_INIT *initid)
{
}


my_bool distance_sphere_init(UDF_INIT *initid,
			     UDF_ARGS *args,
			     char *message)
{
  if(args->arg_count != 2){
    strcpy(message,
	   "wrong number of arguments: DISTANCE_SPHERE() requires two arguments");
    return 1;
  }
  if(args->arg_type[0] != STRING_RESULT
     || args->arg_type[1] != STRING_RESULT){
    strcpy(message,
	   "wrong argument type: DISTANCE_SPHERE() requires two GEOMETRY");
    return 1;
  }

  initid->decimals = 10;
  initid->maybe_null = 1; // The result may be null

  return 0; // OK
}

double distance_sphere(UDF_INIT *initid,
		       UDF_ARGS *args,
		       char *is_null,
		       char *error)
{
  if(args->args[0] == 0 || args->args[1] == 0){ // Return NULL for NULL values
    *is_null = 1;
    return 0;
  }

  if(args->lengths[0] < sizeof (Geometry)
     || args->lengths[1] < sizeof (Geometry)){
    *error = 1;
    return 0;
  }

  Geometry *g1, *g2;
  Geometry_buffer buffer1, buffer2;
  g1 = Geometry::construct(&buffer1, args->args[0], args->lengths[0]);
  g2 = Geometry::construct(&buffer2, args->args[1], args->lengths[1]);
  int mtypeid1 = g1->get_class_info()->m_type_id;
  int mtypeid2 = g1->get_class_info()->m_type_id;
  if(mtypeid1 != Geometry::wkb_point || mtypeid2 != Geometry::wkb_point){
    *error = 1;
    return 0;
  }

  double x1, x2, y1, y2;
  ((Gis_point *)g1)->get_xy(&x1, &y1);
  ((Gis_point *)g2)->get_xy(&x2, &y2);
  if(x1 == x2 && y1 == y2){
    return 0.0;
  }

  return calc_distance_sphere(x1, y1, x2, y2);
}

void distance_sphere_deinit(UDF_INIT *initid)
{
}

